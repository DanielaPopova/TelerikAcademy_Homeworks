﻿namespace Dealership.Common.Enums
{
    public enum VehicleType
    {
        Motorcycle = 2,
        Car = 4,
        Truck = 8
    }
}